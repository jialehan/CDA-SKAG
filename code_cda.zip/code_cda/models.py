import torch
import torch.nn as nn
import torch.nn.functional as F
from .attention_enhancing_layer import attention_enhancing_layer


class GraphConv(nn.Module):
    def __init__(self,in_dim,out_dim,drop=0.5,bias=False,activation=None):
        super(GraphConv,self).__init__()
        self.dropout = nn.Dropout(drop)
        self.activation = activation
        self.w = nn.Linear(in_dim,out_dim,bias=bias)
        nn.init.xavier_uniform_(self.w.weight)
        self.bias = bias
        if self.bias:
            nn.init.zeros_(self.w.bias)


    def forward(self,adj,x):
        x = self.dropout(x)
        x = adj.mm(x)
        x = self.w(x)
        if self.activation:
            return self.activation(x)

class GraphConv1(nn.Module):
    def __init__(self,in_dim,out_dim,drop=0.5,bias=False,activation=None):
        super(GraphConv1,self).__init__()
        self.dropout = nn.Dropout(drop)
        self.activation = activation
        self.w = nn.Linear(in_dim,out_dim,bias=bias)
        nn.init.xavier_uniform_(self.w.weight)
        self.bias = bias
        if self.bias:
            nn.init.zeros_(self.w.bias)


    def forward(self,adj,x):
        x = self.dropout(x)
        x = adj.mm(x)
        x = self.w(x)
        hidden_attention = x
        hidden_new = x
        for cv in range(0, 1):
            hidden_attention = attention_enhancing_layer(hidden_attention, hidden_new)
            hidden_new = hidden_attention
            x = hidden_attention
        if self.activation:
            return self.activation(x)
        else:
            return x


class LP(nn.Module):
    def __init__(self, hid_dim, out_dim, bias=False):
        super(LP, self).__init__()
        self.res1 = GraphConv1(out_dim, hid_dim, bias=bias, activation=torch.tanh)
        self.res4 = GraphConv(hid_dim, out_dim, bias=bias, activation=torch.sigmoid)

    def forward(self, g, z):
        z = self.res1(g, z)
        res = self.res4(g,z)
        return res, z
