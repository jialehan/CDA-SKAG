import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
from code_cda.models import LP
from code_cda.utils import set_seed, neighborhood, show_auc
from code_cda.similarity_Kernel_Fusion import SKF


parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=1, help='Random seed.')
parser.add_argument('--epochs', type=int, default=40, # 1200
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-5,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Dimension of representations')
parser.add_argument('--alpha', type=float, default=0.5,
                    help='Weight between miRNA space and disease space')
parser.add_argument('--data', type=int, default=1, choices=[1,2],
                    help='Dataset')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()
set_seed(args.seed,args.cuda)


def scaley(ymat):
    return (ymat-ymat.min())/ymat.max()

def normalized(wmat):
    deg = np.diag(np.sum(wmat,axis=0))
    degpow = np.power(deg,-0.5)
    degpow[np.isinf(degpow)] = 0
    W = np.dot(np.dot(degpow,wmat),degpow)
    return W

def norm_adj(feat):
    C = neighborhood(feat.T,k=10)
    norm_adj = normalized(C.T*C+np.eye(C.shape[0]))
    g = torch.from_numpy(norm_adj).float()
    return g

ccf = np.loadtxt('../datasets/circRNA functional similarity.txt',delimiter=',')
ddf = np.loadtxt('../datasets/disease semantic similarity.txt',delimiter=',')
ccs = np.loadtxt('../datasets/circRNA GIP similarity.txt',delimiter=',')
dds = np.loadtxt('../datasets/disease GIP similarity.txt',delimiter=',')
cdi = np.loadtxt('../datasets/Association matrix.txt',delimiter=',')
cdit = torch.from_numpy(cdi).float()

print('Fusion start.')
cc = SKF(ccf,ccs)
dd = SKF(ddf,dds)
# # 线性加权融合
# cc = 0.5*ccf+0.5*ccs
# dd = 0.5*ddf+0.5*dds
print('Fusion end.')

gc = normalized(cc)
gd = normalized(dd)
gc = torch.from_numpy(gc).float()
gd = torch.from_numpy(gd).float()
if args.cuda:
    cdit = cdit.cuda()
    gc = gc.cuda()
    gd = gd.cuda()


class GNNp(nn.Module):
    def __init__(self):
        super(GNNp,self).__init__()
        self.gnnpl = LP(cdi.shape[0], cdi.shape[1])
        self.gnnpd = LP(cdi.shape[1], cdi.shape[0])

    def forward(self,y0):
        yl, zl = self.gnnpl(gc, y0)
        yd, zd = self.gnnpd(gd, y0.t())
        return yl, zl, yd, zd  # yl,yd 还原后的结果，zl，zd 隐层向量


print("Dataset {}, 5-fold CV".format(args.data))

def criterion(output,target,msg,n_nodes,mu,logvar):
    if msg == 'disease':
        cost = F.binary_cross_entropy(output,target)
    else:
        cost = F.mse_loss(output,target)
    
    KL = -0.5 / n_nodes * torch.mean(torch.sum(
        1 + 2 * logvar - mu.pow(2) - logvar.exp().pow(2), 1))
    return cost + KL

def loss_function(pre_adj, adj):
    # adj = torch.Tensor(adj)
    class_weight = Variable(torch.FloatTensor([1, 5])).cuda() # the proportion of positive and negative samples, which is a manual adjustment parameters
    weight = class_weight[adj.long()]
    loss_fn = nn.BCELoss(weight)
    return loss_fn(pre_adj,adj)

def train(gnnp,y0,epoch,alpha):
    train_losses = []
    beta = 1.0
    optp = torch.optim.Adam(gnnp.parameters(),lr=args.lr,weight_decay=args.weight_decay)
    for e in range(epoch):
        gnnp.train()
        yl,zl,yd,zd = gnnp(y0)
        losspl = loss_function(yl, y0)
        losspd = loss_function(yd, y0.t())
        value = alpha*yl+(1-alpha)*yd.t()
        lossp = beta*(alpha*losspl + (1-alpha)*losspd)
        optp.zero_grad()
        lossp.backward()
        optp.step()
        with torch.no_grad():
            yl,zl,yd,zd = gnnp(y0)
        gnnp.eval()
        if e%20 == 0 and e!=0:
            print('Epoch %d | Lossp: %.4f' % (e, lossp.item()))
        train_losses.append(lossp.item())

    return alpha*yl+(1-alpha)*yd.t()

def trainres(A0):
    gnnp = GNNp()
    if args.cuda:
        gnnp = gnnp.cuda()

    train(gnnp,A0,args.epochs,args.alpha)
    gnnp.eval()
    yli,_,ydi,_ = gnnp(A0)
    resi = args.alpha*yli + (1-args.alpha)*ydi.t()
    return resi

def fivefoldcv(A,alpha=0.5):
    N = A.shape[0]
    idx = np.arange(N)
    np.random.shuffle(idx)
    res = torch.zeros(5,A.shape[0],A.shape[1])
    aurocl = np.zeros(5)
    auprl = np.zeros(5)
    for i in range(5):
        print("Fold {}".format(i+1))
        A0 = A.clone()
        for j in range(i*N//5,(i+1)*N//5):
            A0[idx[j],:] = torch.zeros(A.shape[1])
        resi = trainres(A0)
        res[i] = resi
        if args.cuda:
            resi = resi.cpu().detach().numpy()
        else:
            resi = resi.detach().numpy()
        auroc, aupr = show_auc(resi, args.data, i)
        aurocl[i] = auroc
        auprl[i] = aupr
        i = i+1

    ymat = res[aurocl.argmax()]
    if args.cuda:
        return ymat.cpu().detach().numpy()
    else:
        return ymat.detach().numpy()


title = 'result--dataset' + str(args.data)
ymat = fivefoldcv(cdit, alpha=args.alpha)
title += '--fivefoldcv'
ymat = scaley(ymat)
show_auc(ymat, args.data, 5)


