import numpy as np
import math
from numpy.matlib import repmat


def Getgauss(adjacentmatrix,nm):
       """
       circRNA Gaussian interaction profile kernels similarity
       """
       KM = np.zeros((nm,nm))

       gamaa=1.5
       sumnormm=0
       for i in range(nm):
           normm = np.linalg.norm(adjacentmatrix[i])**2
           sumnormm = sumnormm + normm
       gamam = gamaa/(sumnormm/nm)


       for i in range(nm):
              for j in range(nm):
                      KM[i,j]= math.exp (-gamam*(np.linalg.norm(adjacentmatrix[i]-adjacentmatrix[j])**2))
       return KM


def Getgauss_disease(adjacentmatrix,nd):
       """
       Disease Gaussian interaction profile kernels similarity
       """
       KD = np.zeros((nd,nd))
       gamaa=1.5
       sumnormd=0
       for i in range(nd):
              normd = np.linalg.norm(adjacentmatrix[:,i])**2
              sumnormd = sumnormd + normd
       gamad=gamaa/(sumnormd/nd)

       for i in range(nd):
           for j in range(nd):
               KD[i,j]= math.exp(-(gamad*(np.linalg.norm(adjacentmatrix[:,i]-adjacentmatrix[:,j])**2)))
       return KD

def FindDominateSet(W,K):
    m,n = W.shape
    YW = np.argsort(-W,axis = 1)
    newW = np.zeros((m,n))
    temp = np.zeros((m,K))
    I1 = np.zeros((m,K))
    for i in range(m):
        for j in range(K):
            temp[i][j] = i
    for i in range(m):
        for j in range(K):
            I1[i][j] = temp[i][j] + (YW[i][j])*m
    for i in range(m):
        for j in range(36):
            if I1[i][j]<m*n:
                p = int(I1[i][j]/m)
                q = int(I1[i][j]%m)
                newW[p][q] = W[p][q]
    A = np.sum(newW, axis = 1)
    A = A.reshape(m,1)
    return newW

def neighborhood(similar_m,kk):
    m,n = similar_m.shape
    similarities_N = np.zeros((m,n))
    for i in range(m):
        for j in range(n):
            iu = similar_m[i,:]
            iu_list = sorted(iu,reverse = True)
            iu_kmax = iu_list[kk]
            ju = similar_m[:,j]
            ju_list = sorted(ju,reverse=True)
            ju_kmax = ju_list[kk]
            if (similar_m[i][j]>=iu_kmax) & (similar_m[i][j]>=ju_kmax):
                similarities_N[i][j] = 1
                similarities_N[j][i] = 1
            else:
                if (similar_m[i][j]<iu_kmax) & (similar_m[i][j]<ju_kmax):
                    similarities_N[i][j] = 0
                    similarities_N[j][i] = 0
                else :
                    similarities_N[i][j] = 0.5
                    similarities_N[j][i] = 0.5

    return similarities_N

def convergence_cal(s1a,s1):
    s1b = s1a-s1
    s1a = np.linalg.norm(s1b, ord=1, axis=None, keepdims=False)
    s1 = np.linalg.norm(s1, ord=1, axis=None, keepdims=False)
    result = s1a/s1
    return result

def SKF(S1,S2):
    #  the number of neighbors k, the weighting coefficient α, and the number of iterations t
    k = 36
    t = 12
    alpha = 0.8
    m,n = S1.shape

    new_S1 = S1 / repmat(np.sum(S1, axis = 0), n, 1)  # S1/46或38
    new_S2 = S2 / repmat(np.sum(S2, axis = 0), n, 1)  # S2/46或38
    sumS = new_S1 + new_S2
    S1 = S1/repmat(np.sum(S1,axis = 0),n,1)
    S2 = S2/repmat(np.sum(S2,axis = 0),n,1)
    S11 = FindDominateSet(S1,k)
    S21 = FindDominateSet(S2, k)
    # Wsum = np.zeros((m,n))
    Wsum = S1 + S2
    for i in range(t):
        S1a = S1
        S2a = S2
        S1 = alpha * S11 * (Wsum - S1) * S1.T / 2 + (1 - alpha) * (sumS - new_S1) / 2
        S2 = alpha * S21 * (Wsum - S2) * S2.T / 2 + (1 - alpha) * (sumS - new_S2) / 2
        Wsum = np.zeros((m, n))
        Wsum = S1 + S2
        result1 = convergence_cal(S1a, S1)
        result2 = convergence_cal(S2a, S2)
        print("EC=", result1, "ED=", result2)
    W = Wsum/2
    W1 = neighborhood(W,k)
    W = W*W1
    return W










