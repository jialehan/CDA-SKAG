# _*_ coding:utf-8 _*_
#开发人员：lenovo
#开发时间：2022/9/18_11:14
#文件名： attention_enhancing_layer.py
#开发工具：PyCharm
import numpy as np
import torch
import torch.nn as nn

def adj_to_bias(sizes=[100], nhood=1):
    matrix = np.loadtxt("../datasets/Association matrix.txt",delimiter=',')
    matrix = torch.from_numpy(matrix).float()
    M = matrix
    adj= matrix
    adj = np.vstack((np.hstack((np.zeros(shape=(585, 585), dtype=int), M)),
                     np.hstack((M.t(), np.zeros(shape=(88, 88), dtype=int)))))
    adj = adj + np.eye(adj.shape[0])
    adj = np.reshape(adj, (1, adj.shape[0], adj.shape[1]))
    nb_graphs = adj.shape[0]
    mt = np.empty(adj.shape)
    for g in range(nb_graphs):
        mt[g] = np.eye(adj.shape[1])
        for _ in range(nhood):
            mt[g] = np.matmul(mt[g], (adj[g] + np.eye(adj.shape[1])))
        for i in range(sizes[g]):
            for j in range(sizes[g]):
                if mt[g][i][j] > 0.0:
                    mt[g][i][j] = 1.0
    return -1e9 * (1.0 - mt)


def dot(x, y, sparse=False):
    res = torch.mm(x,y)
    return res


def attention_enhancing_layer(hidden, hidden_new):
    alpha = 50
    beta = 1  # 50

    bias_mat = adj_to_bias(sizes=hidden.shape, nhood=1)
    bias_mat = torch.from_numpy(bias_mat)
    hidden_extend = hidden[np.newaxis]

    attention = Attention(hidden_extend.shape[0], bias_mat.shape, hidden.shape[1])
    attention.cuda()
    coefs = attention(hidden_extend, bias_mat)  # hidden.shape[1]
    coefs = coefs[0].to(torch.float32)  # torch.float64转torch.float32

    hidden_neighbor = torch.multiply(dot(coefs, hidden_new), beta)
    hidden_self = torch.multiply(hidden, alpha)
    hidden_crf = torch.add(hidden_neighbor, hidden_self)

    unit_mat = torch.ones((hidden.shape[0], hidden.shape[1]), dtype=torch.float32)
    unit_mat = unit_mat.cuda()
    coff_sum = torch.multiply(dot(coefs, unit_mat), beta)
    const =  torch.add(coff_sum, torch.multiply(unit_mat, alpha))

    hidden_crf = torch.div(hidden_crf, const)
    return hidden_crf


class Attention(nn.Module):
    def __init__(self,hidden_sz, bias_mat, hidden_shape1, out_sz=25):
        super(Attention, self).__init__()
        self.Conv1 = nn.Conv1d(hidden_sz, out_sz, 1)
        self.Conv2 = nn.Conv1d(out_sz, 1, 1)
        self.softmax = nn.Softmax()

    def forward(self,emb, bias_mat, out_sz=25):
        bias_mat = bias_mat.cuda()
        input = emb.permute(1,0,2).contiguous()
        seq_fts = self.Conv1(input)
        f_1 = self.Conv2(seq_fts)
        f_2 = self.Conv2(seq_fts)
        f_1 = f_1.permute(1, 0, 2).contiguous()
        f_2 = f_2.permute(1, 0, 2).contiguous()
        logits = f_1 + f_2.permute(0, 2, 1).contiguous()
        coefs = self.softmax(torch.relu(logits))

        return coefs

if __name__ == '__main__':
    x= torch.ones(64,64)
    hidden_attention = x  # 韩加
    hidden_new = x  # 韩加
    for cv in range(0, 1):
        hidden_crf = attention_enhancing_layer(hidden_attention, hidden_new)
        hidden_new = hidden_crf
        x = hidden_crf